#ifndef __STRING_LIST_H__
#define __STRING_LIST_H__

#include <vector>
#include "String.h"

typedef std::vector<String> StringList;

#endif