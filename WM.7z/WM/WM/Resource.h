//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Convertor.rc
//
#define IDD_CONVERTOR_DIALOG            102
#define IDD_SETTINGS_DIALOG             104
#define IDD_ABOUT_DIALOG                105
#define IDR_CONVERTOR_ICON              128
#define IDR_CONVERTOR_MENU              131
#define IDC_COMBO1                      1000
#define IDC_EDIT1                       1001
#define IDC_EDIT2                       1002
#define IDC_EDIT3                       1003
#define IDC_EDIT4                       1004
#define IDC_EDIT5                       1005
#define IDC_EDIT6                       1006
#define IDC_EDIT7                       1007
#define IDC_EDIT8                       1008
#define IDC_EDIT9                       1009
#define IDC_LABEL1                      1010
#define IDC_LABEL2                      1011
#define IDC_LABEL3                      1012
#define IDC_LABEL4                      1013
#define IDC_LABEL5                      1014
#define IDC_LABEL6                      1015
#define IDC_LABEL7                      1016
#define IDC_LABEL8                      1017
#define IDC_LABEL9                      1018
#define IDC_GROUP1                      1019
#define IDC_LABEL10                     1020
#define IDC_LABEL11                     1021
#define IDC_LABEL12                     1022
#define IDC_LABEL13                     1023
#define IDC_LABEL14                     1024
#define IDC_LABEL15                     1025
#define IDC_LABEL16                     1026
#define IDC_LABEL17                     1027
#define IDC_LABEL18                     1028
#define IDC_LANGUAGE                    1030
#define IDC_ABOUT_TEXT                  1031
#define IDC_BUTTON1                     1032
#define ID_TOOLS_QUIT                   32771
#define ID_TOOLS_CALCULATOR             32772
#define ID_HELP_HELP                    32774
#define ID_HELP_ABOUT                   32775
#define ID_HELP_LICENCE                 32776
#define ID_TOOLS_SETTINGS               32778
#define ID_TOOLS_REPORT                 32779
#define ID_HELP_HOMEPAGE                32780

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32781
#define _APS_NEXT_CONTROL_VALUE         1033
#define _APS_NEXT_SYMED_VALUE           106
#endif
#endif
