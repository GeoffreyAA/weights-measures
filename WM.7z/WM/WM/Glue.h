#ifndef __GLUE_H__
#define __GLUE_H__

#ifdef _AFXDLL

bool HtmlHelp(const wchar_t *pszFile = NULL, const wchar_t *pszPage = NULL, HWND hOwner = NULL);

#endif

#endif